<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"D:\phpStudy\WWW\newmedia\public/../application/index\view\manager\phonelist.html";i:1539493508;s:71:"D:\phpStudy\WWW\newmedia\application\index\view\common\admin-slide.html";i:1539595227;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>新媒体账号管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="新媒体账号管理系统-管理员-手机信息管理界面" />
    <meta content="Mosheng" name="author" />
    <link rel="shortcut icon" href="__PUBLIC__assets/images/favicon.ico">

    <!-- App css -->
    <link href="__PUBLIC__css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/self.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <header id="topnav">
    <nav class="navbar-custom">
        <div class="container-fluid">
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                        <img src="__PUBLIC__assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
                        <small class="pro-user-name ml-1">
                            <?php echo \think\Session::get('name'); ?>
                        </small>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated profile-dropdown ">
                        <!-- item-->
                        <a href="<?php echo url('Index/lgout'); ?>" class="dropdown-item notify-item">
                            <i class="fe-log-out"></i>
                            <span>退出</span>
                        </a>

                    </div>
                </li>
            </ul>
            <ul class="list-inline menu-left mb-0">
                <li class="float-left">
                    <a href="index.html" class="logo">
                        <span class="logo-lg">
                            <img src="__PUBLIC__assets/images/logo.png" alt="" height="18">
                        </span>
                    </a>
                </li>
            </ul>

          
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/wxlist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            微信账号管理
                        </small>
                    </a>
                </li>
            </ul>

            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/kslist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            快手账号管理
                        </small>
                    </a>
                </li>
            </ul>

            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/dylist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            抖音账号管理
                        </small>
                    </a>
                </li>
            </ul>
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0"   href="<?php echo url('Manager/phonelist'); ?>"  >
                        <small class="pro-user-name ml-1">
                            手机信息管理
                        </small>
                    </a>
                </li>
            </ul>
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0"   href="<?php echo url('Manager/index'); ?>"  >
                        <small class="pro-user-name ml-1">
                            账号信息展示
                        </small>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- topbar-menu -->
    <!-- <div class="topbar-menu">
        <div class="container-fluid">
            <div id="navigation">
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-layers"></i>手机信息管理
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/douyin'); ?>">抖音</a>
                            </li>
                            <li>
                                <a href="<?php echo url('Manager/weibo'); ?>">微博</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-package"></i>抖音账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/platformlist'); ?>">营销平台列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-grid"></i>快手账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/accountlist'); ?>">营销账号列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-layers"></i>微信账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="components-elements.html">用户列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    </div> -->

</header>
    <!-- container-fluid     -->
    <div class="wrapper">
        <div class="container-fluid">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">手机信息管理</h4>
                        <a href="<?php echo url('Manager/addphone'); ?>" class="btn btn-success btn-sm float-right">添加手机信息</a>
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>手机编号</th>
                                    <th>手机品牌</th>
                                    <th>SIM卡1</th>
                                    <th>SIM卡2</th>
                                    <th>开户名（卡1）</th>
                                    <th>开户名（卡2）</th>
                                    <th>负责人</th>
                                    <th>更新时间</th>
                                    <th>编辑</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(is_array($sel) || $sel instanceof \think\Collection || $sel instanceof \think\Paginator): $i = 0; $__LIST__ = $sel;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$a): $mod = ($i % 2 );++$i;switch($name=($i+1)%2): case "0": ?>
                                <tr class="table-bg text-text">
                                    <th><?php echo $i; ?></th>
                                    <th><?php echo $a['phonesn']; ?></th>
                                    <th><?php echo $a['phonebrand']; ?></th>
                                    <th><?php echo $a['phonesim1']; ?></th>
                                    <th><?php echo $a['phonesim2']; ?></th>
                                    <th><?php echo $a['phonecreate1']; ?></th>
                                    <th><?php echo $a['phonecreate2']; ?></th>
                                    <th><?php echo $a['phonecharge']; ?></th>
                                    <th><?php echo date("Y-m-d",$a['time']); ?></th>
                                    <td><a href="editphone?id=<?php echo $a['id']; ?>">编辑</a>|<a href="delphone?id=<?php echo $a['id']; ?>" onclick="return confirm('确定要删除吗?')">删除</a></td>
                                </tr>
                                <?php break; case "1": ?>
                                <tr class="">
                                    <th><?php echo $i; ?></th>
                                    <th><?php echo $a['phonesn']; ?></th>
                                    <th><?php echo $a['phonebrand']; ?></th>
                                    <th><?php echo $a['phonesim1']; ?></th>
                                    <th><?php echo $a['phonesim2']; ?></th>
                                    <th><?php echo $a['phonecreate1']; ?></th>
                                    <th><?php echo $a['phonecreate2']; ?></th>
                                    <th><?php echo $a['phonecharge']; ?></th>
                                    <th><?php echo date("Y-m-d",$a['time']); ?></th>
                                    <td><a href="editphone?id=<?php echo $a['id']; ?>">编辑</a>|<a href="delphone?id=<?php echo $a['id']; ?>" onclick="return confirm('确定要删除吗?')">删除</a></td>
                                </tr>
                                <?php break; endswitch; endforeach; endif; else: echo "$empty" ;endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Start -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    kuaidao Admin &copy; 2018 - tecms.net
                </div>
            </div>
        </div>
    </footer>


    <!-- App js -->
    <script src="__PUBLIC__js/vendor.min.js"></script>
    <script src="__PUBLIC__js/app.min.js"></script>

    <!-- Plugins js -->
    <script src="__PUBLIC__js/vendor/Chart.bundle.js"></script>
    <script src="__PUBLIC__js/vendor/jquery.sparkline.min.js"></script>
    <script src="__PUBLIC__js/vendor/jquery.knob.min.js"></script>

    <script src="__PUBLIC__js/pages/dashboard.init.js"></script>

</body>

</html>