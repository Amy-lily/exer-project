<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:74:"E:\phpStudy\WWW\newmedia\public/../application/index\view\index\index.html";i:1539942392;s:70:"E:\phpStudy\WWW\newmedia\application\index\view\common\user-slide.html";i:1539324986;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>管理员首页</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="后台管理系统-管理员-首页" />
    <meta content="Mosheng" name="author" />
    <link rel="shortcut icon" href="__PUBLIC__assets/images/favicon.ico">

    <!-- App css -->
    <link href="__PUBLIC__css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/self.css" rel="stylesheet" type="text/css" />
    <style>
        td {
            cursor: pointer;
        }

        .echart-box {
            width: 100%;
            height: 100%;
            overflow: hidden;
            position: fixed;
            top: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.6);
            display: none;
        }

        #main {
            width: 1200px;
            height: 600px;
            background: #000;
            position: fixed;
            left: 50%;
            margin-left: -600px;
            top: 50%;
            margin-top: -300px;
            display: none;
        }
    </style>
</head>

<body>
    <header id="topnav">
    <nav class="navbar-custom">
        <div class="container-fluid">
            <ul class="list-unstyled topbar-right-menu float-right mb-0">

                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Index/login'); ?>" >登陆</a>
                </li>
            </ul>
            <ul class="list-inline menu-left mb-0">
                <li class="float-left">
                    <a href="index.html" class="logo">
                        <span class="logo-lg">
                            <img src="__PUBLIC__assets/images/logo.png" alt="" height="18">
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- topbar-menu -->
    <div class="topbar-menu">
        <div class="container-fluid">
            <div id="navigation">
                <div class="clearfix"></div>
            </div>
        </div>
    </div>

</header>
    <div class="wrapper">
        <table class="table table-self  mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th colspan="2" class="text text-one">手机信息</th>
                    <th colspan="2" class="text text-two">手机号</th>
                    <th colspan="2" class="text text-three">手机号开户名</th>
                    <th colspan="3" class="text text-four">抖音</th>
                    <th colspan="3" class="text text-five">快手</th>
                    <th colspan="3" class="text text-six">微信</th>
                    <th class="text text-eight">负责人</th>
                </tr>
                <tr>
                    <th>#</th>
                    <th>手机编号</th>
                    <th>手机品牌</th>
                    <th>SIM卡1</th>
                    <th>SIM卡2</th>
                    <th>开户名（卡1）</th>
                    <th>开户名（卡2）</th>
                    <th>账号</th>
                    <th>名称</th>
                    <th>粉丝量（万）</th>
                    <th>账号</th>
                    <th>名称</th>
                    <th>粉丝量（万）</th>
                    <th>账号</th>
                    <th>微信名</th>
                    <th>好友量</th>
                    <th>负责人</th>
                </tr>
            </thead>
            <tbody>
                <?php if(is_array($sel) || $sel instanceof \think\Collection || $sel instanceof \think\Paginator): $i = 0; $__LIST__ = $sel;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$a): $mod = ($i % 2 );++$i;switch($name=($i+1)%2): case "0": ?>
                <tr class="table-bg text-text">
                    <td><?php echo $i; ?></td>
                    <td><?php echo $a['phonesn']; ?></td>
                    <td><?php echo $a['phonebrand']; ?></td>
                    <td><?php echo substr_replace($a['phonesim1'],'****',3,4); ?></td>
                    <td><?php echo substr_replace($a['phonesim2'],'****',3,4); ?></td>
                    <td><?php echo $a['phonecreate1']; ?></td>
                    <td><?php echo $a['phonecreate2']; ?></td>
                    <td><?php echo substr_replace($a['dyaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['dyname']; ?></td>
                    <td class="text-fans" onclick="dyfans(<?php echo $a['id']; ?>,'dy')"><?php echo $a['dyfans']; ?></td>
                    <td><?php echo substr_replace($a['ksaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['ksname']; ?></td>
                    <td class="text-fans" onclick="dyfans(<?php echo $a['id']; ?>,'ks')"><?php echo $a['ksfans']; ?></td>
                    <td><?php echo substr_replace($a['wxaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['wxname']; ?></td>
                    <td class="text-fans" onclick="dyfans(<?php echo $a['id']; ?>,'wx')" }><?php echo $a['wxfans']; ?></td>
                    <td><?php echo $a['phonecharge']; ?></td>
                </tr>
                <?php break; case "1": ?>
                <tr class="">
                    <td><?php echo $i; ?></td>
                    <td><?php echo $a['phonesn']; ?></td>
                    <td><?php echo $a['phonebrand']; ?></td>
                    <td><?php echo substr_replace($a['phonesim1'],'****',3,4); ?></td>
                    <td><?php echo substr_replace($a['phonesim2'],'****',3,4); ?></td>
                    <td><?php echo $a['phonecreate1']; ?></td>
                    <td><?php echo $a['phonecreate2']; ?></td>
                    <td><?php echo substr_replace($a['dyaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['dyname']; ?></td>
                    <td class="text-fans" onclick="dyfans(<?php echo $a['id']; ?>,'dy')"><?php echo $a['dyfans']; ?></td>
                    <td><?php echo substr_replace($a['ksaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['ksname']; ?></td>
                    <td class="text-fans" onclick="dyfans(<?php echo $a['id']; ?>,'ks')"><?php echo $a['ksfans']; ?></td>
                    <td><?php echo substr_replace($a['wxaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['wxname']; ?></td>
                    <td class="text-fans" onclick="dyfans(<?php echo $a['id']; ?>,'wx')" }><?php echo $a['wxfans']; ?></td>
                    <td><?php echo $a['phonecharge']; ?></td>
                </tr>
                <?php break; endswitch; endforeach; endif; else: echo "$empty" ;endif; ?>
            </tbody>
        </table>


    </div>
    <div class="echart-box">
        <div id="main"></div>
    </div>
    <div class="table-footer">
        <table class="table table-self  mb-0">
            <tr class="table-bg text-text table-amount">
                <td>合计</td>
                <td>抖音、快手账号总数：</td>
                <td>抖音总粉丝量:</td>
                <td>快手总粉丝量：</td>
                <td>微信总粉丝量：</td>
            </tr>
        </table>
    </div>




    <!-- App js -->
    <script src="__PUBLIC__js/vendor.min.js"></script>
    <script src="__PUBLIC__js/app.min.js"></script>

    <!-- Plugins js -->
    <script src="__PUBLIC__js/vendor/Chart.bundle.js"></script>
    <script src="__PUBLIC__js/vendor/jquery.sparkline.min.js"></script>
    <script src="__PUBLIC__js/pulibc.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts.min.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts-gl/echarts-gl.min.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts-stat/ecStat.min.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/dataTool.min.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/china.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/world.js"></script>
    <script type="text/javascript" src="https://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/bmap.min.js"></script>
    <script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/simplex.js"></script>
    <script>
        function dyfans(id, type) {

            $.ajax({
                url: url + 'Index/index/dyfans',
                type: 'POST',
                data: {
                    'id': id
                },
                success: function (res) {
                    var result = JSON.parse(res);
                    var title;//定义图表标题
                    var times = [];//横坐标
                    var fans = [];//粉丝
                    if (res != null) {
                        $('.echart-box').show();
                        $('#main').show();
                        switch (type) {
                            case 'dy':
                                title = '抖音';
                                break;
                            case 'ks':
                                title = '快手';
                                break;
                            case 'wx':
                                title = '微信';
                                break;
                        };

                        var app = {};
                        option = null;
                        app.title = '坐标轴刻度与标签对齐';
                        // 指定图表的配置项和数据
                        var myChart = echarts.init(document.getElementById('main'));
                        // 将时间戳转换成日期 
                        function getLocalTime(nS) {
                            // var date =  new Date(parseInt(nS) * 1000).toLocaleDateString().replace(/:\d{1,2}$/, '');
                            var date = new Date(parseInt(nS) * 1000);
                            var y = date.getUTCFullYear();
                            var m = date.getUTCMonth() + 1;
                            var d = date.getUTCDate();
                            return `${y}年-${m}月-${d}日`;
                        }
                        for (var i = 0; i < result.length; i++) {
                            times[i] = getLocalTime(result[i]['time']);
                            fans[i] = result[i]['dyfans'];
                        }
                        var restime = [];
                        var arr = ["2018年-10月-17日", "2018年-10月-18日", "2018年-10月-18日"];
                        for (var m = 0; m < times.length; m++) {
                            if (times[m + 1] == times[m]) {
                                times.splice(m, 1);
                            }
                        }
                        console.log(times);
                            // 指定图表的配置项和数据
                            var option = {
                                backgroundColor: "#fff",
                                title: {
                                    text: result[0].dyaccount + title + ' 柱状图'
                                },
                                color: ['#3398DB'],
                                tooltip: {
                                    trigger: 'axis',
                                    axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                                        type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                                    }
                                },
                                grid: {

                                    containLabel: true
                                },
                                xAxis: [
                                    {
                                        type: 'category',
                                        data: times,
                                        axisTick: {
                                            alignWithLabel: true
                                        }
                                    }
                                ],
                                yAxis: [
                                    {
                                        type: 'value'
                                    }
                                ],
                                series: [
                                    {
                                        name: '粉丝量（万）',
                                        type: 'bar',
                                        barWidth: '20%',
                                        data: fans
                                    }
                                ]
                            };
                        // 使用刚指定的配置项和数据显示图表。
                        myChart.setOption(option);
                        $('.echart-box').click(function () {
                            $('.echart-box').hide();
                            $('#main').hide();

                        })
                    }
                }
            });
        }
    </script>
</body>

</html>