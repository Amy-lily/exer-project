<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:74:"D:\phpStudy\WWW\newmedia\public/../application/index\view\index\index.html";i:1539841478;s:71:"D:\phpStudy\WWW\newmedia\application\index\view\common\admin-slide.html";i:1539595227;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>管理员首页</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="后台管理系统-管理员-首页" />
    <meta content="Mosheng" name="author" />
    <link rel="shortcut icon" href="__PUBLIC__assets/images/favicon.ico">

    <!-- App css -->
    <link href="__PUBLIC__css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/self.css" rel="stylesheet" type="text/css" />
    <style>
       
    </style>
</head>

<body>
    <header id="topnav">
    <nav class="navbar-custom">
        <div class="container-fluid">
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                        <img src="__PUBLIC__assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
                        <small class="pro-user-name ml-1">
                            <?php echo \think\Session::get('name'); ?>
                        </small>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated profile-dropdown ">
                        <!-- item-->
                        <a href="<?php echo url('Index/lgout'); ?>" class="dropdown-item notify-item">
                            <i class="fe-log-out"></i>
                            <span>退出</span>
                        </a>

                    </div>
                </li>
            </ul>
            <ul class="list-inline menu-left mb-0">
                <li class="float-left">
                    <a href="index.html" class="logo">
                        <span class="logo-lg">
                            <img src="__PUBLIC__assets/images/logo.png" alt="" height="18">
                        </span>
                    </a>
                </li>
            </ul>

          
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/wxlist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            微信账号管理
                        </small>
                    </a>
                </li>
            </ul>

            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/kslist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            快手账号管理
                        </small>
                    </a>
                </li>
            </ul>

            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/dylist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            抖音账号管理
                        </small>
                    </a>
                </li>
            </ul>
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0"   href="<?php echo url('Manager/phonelist'); ?>"  >
                        <small class="pro-user-name ml-1">
                            手机信息管理
                        </small>
                    </a>
                </li>
            </ul>
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0"   href="<?php echo url('Manager/index'); ?>"  >
                        <small class="pro-user-name ml-1">
                            账号信息展示
                        </small>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- topbar-menu -->
    <!-- <div class="topbar-menu">
        <div class="container-fluid">
            <div id="navigation">
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-layers"></i>手机信息管理
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/douyin'); ?>">抖音</a>
                            </li>
                            <li>
                                <a href="<?php echo url('Manager/weibo'); ?>">微博</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-package"></i>抖音账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/platformlist'); ?>">营销平台列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-grid"></i>快手账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/accountlist'); ?>">营销账号列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-layers"></i>微信账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="components-elements.html">用户列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    </div> -->

</header>
    <div id="main" style=""></div>
    <div class="wrapper">
        <table class="table table-self  mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th colspan="2" class="text text-one">手机信息</th>
                    <th colspan="2" class="text text-two">手机号</th>
                    <th colspan="2" class="text text-three">手机号开户名</th>
                    <th colspan="3" class="text text-four">抖音</th>
                    <th colspan="3" class="text text-five">快手</th>
                    <th colspan="3" class="text text-six">微信</th>
                    <th class="text text-eight">备注</th>
                </tr>
                <tr>
                    <th>#</th>
                    <th>手机编号</th>
                    <th>手机品牌</th>
                    <th>SIM卡1</th>
                    <th>SIM卡2</th>
                    <th>开户名（卡1）</th>
                    <th>开户名（卡2）</th>
                    <th>账号</th>
                    <th>名称</th>
                    <th>粉丝量（万）</th>
                    <th>账号</th>
                    <th>名称</th>
                    <th>粉丝量（万）</th>
                    <th>账号</th>
                    <th>微信名</th>
                    <th>好友量</th>
                    <th>负责人</th>
                </tr>
            </thead>
            <tbody>
                <?php if(is_array($sel) || $sel instanceof \think\Collection || $sel instanceof \think\Paginator): $i = 0; $__LIST__ = $sel;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$a): $mod = ($i % 2 );++$i;switch($name=($i+1)%2): case "0": ?>
                <tr class="table-bg text-text">
                    <td><?php echo $i; ?></td>
                    <td><?php echo $a['phonesn']; ?></td>
                    <td><?php echo $a['phonebrand']; ?></td>
                    <td><?php echo substr_replace($a['phonesim1'],'****',3,4); ?></td>
                    <td><?php echo substr_replace($a['phonesim2'],'****',3,4); ?></td>
                    <td><?php echo $a['phonecreate1']; ?></td>
                    <td><?php echo $a['phonecreate2']; ?></td>
                    <td><?php echo substr_replace($a['dyaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['dyname']; ?></td>
                    <td onclick="dyfans()"><?php echo $a['dyfans']; ?></td>
                    <td><?php echo substr_replace($a['ksaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['ksname']; ?></td>
                    <td><?php echo $a['ksfans']; ?></td>
                    <td><?php echo substr_replace($a['wxaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['wxname']; ?></td>
                    <td><?php echo $a['wxfans']; ?></td>
                    <td><?php echo $a['phonecharge']; ?></td>
                </tr>
                <?php break; case "1": ?>
                <tr class="">
                    <td><?php echo $i; ?></td>
                    <td><?php echo $a['phonesn']; ?></td>
                    <td><?php echo $a['phonebrand']; ?></td>
                    <td><?php echo substr_replace($a['phonesim1'],'****',3,4); ?></td>
                    <td><?php echo substr_replace($a['phonesim2'],'****',3,4); ?></td>
                    <td><?php echo $a['phonecreate1']; ?></td>
                    <td><?php echo $a['phonecreate2']; ?></td>
                    <td><?php echo substr_replace($a['dyaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['dyname']; ?></td>
                    <td><a href="/index/index/dyfans?id=<?php echo $a['id']; ?>&actype='dy'"><?php echo $a['dyfans']; ?></a></td>
                    <td><?php echo substr_replace($a['ksaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['ksname']; ?></td>
                    <td><?php echo $a['ksfans']; ?></td>
                    <td><?php echo substr_replace($a['wxaccount'],'****',3,4); ?></td>
                    <td><?php echo $a['wxname']; ?></td>
                    <td><?php echo $a['wxfans']; ?></td>
                    <td><?php echo $a['phonecharge']; ?></td>
                </tr>
                <?php break; endswitch; endforeach; endif; else: echo "$empty" ;endif; ?>
            </tbody>
        </table>
    </div>
    <div class="table-footer">

    </div>
    



    <!-- App js -->
    <script src="__PUBLIC__js/vendor.min.js"></script>
    <script src="__PUBLIC__js/app.min.js"></script>

    <!-- Plugins js -->
    <script src="__PUBLIC__js/vendor/Chart.bundle.js"></script>
    <script src="__PUBLIC__js/vendor/jquery.sparkline.min.js"></script>
    <!-- <script src="__PUBLIC__js/vendor/jquery.knob.min.js"></script>
    <script src="__PUBLIC__js/echarts-all-3.js"></script>
    <script src="__PUBLIC__js/fixed-table.js"></script> -->
    <script>
        function dyfans(){
            alert('2222')
        }
    </script>
</body>

</html>