<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"E:\phpStudy\WWW\newmedia\public/../application/index\view\manager\editwxfans.html";i:1539915543;s:71:"E:\phpStudy\WWW\newmedia\application\index\view\common\admin-slide.html";i:1539595227;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>编辑微信粉丝信息</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="后台管理系统-管理员-编辑微信粉丝信息" />
    <meta content="Mosheng" name="author" />
    <link rel="shortcut icon" href="__PUBLIC__assets/images/favicon.ico">
    <!-- App css -->
    <link href="__PUBLIC__css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="__PUBLIC__css/self.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <header id="topnav">
    <nav class="navbar-custom">
        <div class="container-fluid">
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                        <img src="__PUBLIC__assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
                        <small class="pro-user-name ml-1">
                            <?php echo \think\Session::get('name'); ?>
                        </small>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated profile-dropdown ">
                        <!-- item-->
                        <a href="<?php echo url('Index/lgout'); ?>" class="dropdown-item notify-item">
                            <i class="fe-log-out"></i>
                            <span>退出</span>
                        </a>

                    </div>
                </li>
            </ul>
            <ul class="list-inline menu-left mb-0">
                <li class="float-left">
                    <a href="index.html" class="logo">
                        <span class="logo-lg">
                            <img src="__PUBLIC__assets/images/logo.png" alt="" height="18">
                        </span>
                    </a>
                </li>
            </ul>

          
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/wxlist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            微信账号管理
                        </small>
                    </a>
                </li>
            </ul>

            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/kslist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            快手账号管理
                        </small>
                    </a>
                </li>
            </ul>

            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0" href="<?php echo url('Manager/dylist'); ?>" aria-haspopup="false" aria-expanded="false">
                        <small class="pro-user-name ml-1">
                            抖音账号管理
                        </small>
                    </a>
                </li>
            </ul>
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0"   href="<?php echo url('Manager/phonelist'); ?>"  >
                        <small class="pro-user-name ml-1">
                            手机信息管理
                        </small>
                    </a>
                </li>
            </ul>
            <ul class="list-unstyled topbar-right-menu float-right mb-0">
                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0"   href="<?php echo url('Manager/index'); ?>"  >
                        <small class="pro-user-name ml-1">
                            账号信息展示
                        </small>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- topbar-menu -->
    <!-- <div class="topbar-menu">
        <div class="container-fluid">
            <div id="navigation">
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-layers"></i>手机信息管理
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/douyin'); ?>">抖音</a>
                            </li>
                            <li>
                                <a href="<?php echo url('Manager/weibo'); ?>">微博</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-package"></i>抖音账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/platformlist'); ?>">营销平台列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-grid"></i>快手账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Manager/accountlist'); ?>">营销账号列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navigation-menu">
                    <li class="has-submenu">
                        <a href="#">
                            <i class="fe-layers"></i>微信账号管理</a>
                        <ul class="submenu">
                            <li>
                                <a href="components-elements.html">用户列表</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    </div> -->

</header>
    <!-- container-fluid     -->
    <div class="wrapper">
        <div class="col-lg-6  card-center">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">编辑微信粉丝信息</h4>
                    <hr>
                    <form class="form-horizontal" method="POST">
                        <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
                       
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-3 col-form-label">微信账号</label>
                            <div class="col-9">
                                <input type="text" name="wxaccount" class="form-control" id="inputEmail3" value="<?php echo $info['wxaccount']; ?>" readonly="readonly" placeholder="微信账号">
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-3 col-form-label">微信名称</label>
                            <div class="col-9">
                                <input type="text" name="wxname" class="form-control" id="inputEmail3" value="<?php echo $info['wxname']; ?>" readonly="readonly" placeholder="微信名称">
                            </div>
                        </div>
                        <div class="form-group row mb-3">
                            <label for="inputEmail3" class="col-3 col-form-label">粉丝量</label>
                            <div class="col-3">
                                <input type="text" name="wxfans" class="form-control" id="inputEmail3" value="<?php echo $info['wxfans']; ?>" placeholder="粉丝量">
                            </div>
                            <div class="col-2 float-left">
                                <select class="form-control self-select" data-toggle="select2" name="unit" >
                                    <option value="wan">万</option>
                                    <option value="ge">个</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group mb-0 justify-content-end row">
                            <div class="col-9">
                                <button type="submit" class="btn btn-info">确定修改 </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Start -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    kuaidao Admin &copy; 2018 - tecms.net
                </div>
            </div>
        </div>
    </footer>


    <!-- App js -->
    <script src="__PUBLIC__js/vendor.min.js"></script>
    <script src="__PUBLIC__js/app.min.js"></script>

    <!-- Plugins js -->
    <script src="__PUBLIC__js/vendor/Chart.bundle.js"></script>
    <script src="__PUBLIC__js/vendor/jquery.sparkline.min.js"></script>
    <script src="__PUBLIC__js/vendor/jquery.knob.min.js"></script>

    <script src="__PUBLIC__js/pages/dashboard.init.js"></script>

</body>

</html>