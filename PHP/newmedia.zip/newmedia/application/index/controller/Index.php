<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Session;
class Index extends Controller
{

    public function index(){
        $name = Session('name');
        if($name == NULL){
            $subQuery = Db::table('media-datainfo')
            ->order('id desc')
            ->buildSql();
            $sel = Db::table($subQuery.' a')
                    ->group('a.phonesn')
                    ->select();

            $this->assign('sel',$sel);
            // 抖音、快手账号总数 
            $damount = Db::name('datainfo')->where('dyaccount','<>','')->group('dyaccount')->count();
            $kamount = Db::name('datainfo')->where('ksaccount','<>','')->group('ksaccount')->count();
            // echo $damount;die;
            return $this->fetch();     
        }else{
            return redirect('/Index/Manager/index/');
        }        
    }
    // 登陆页面 
    public function login()
    {
        if(request() -> isPost()){
            $uname = $_POST['uname'];
            $upass = $_POST['upass'];
            $uname = Db::name('user')->where('uname',$uname)->find();
            // 判断用户名 
            if($uname){
                // 判断密码
                if($upass ==  $uname['upass']){                    
                    Session('name',$uname['uname']);//保存用户名
                    Session('Uid',$uname['id']);//保存用户id
                    return $this->success('管理员'.$uname['uname'].'登陆成功','Manager/index');
                }else{
                    return $this->error('密码错误,请重新输入');
                }
            }else{
                return $this->error('用户名输入错误或者不存在，请重新输入');
            }
        }else{
            return $this->fetch();
        }
        
    }
    //退出系统
    public function lgout(){
        Session::clear('think');
        if(1){
            return $this->success('退出系统成功','Index/index');
        }else{
            return $this->error('退出系统失败');
        }
       
    }

    public function dyfans(){
        // $id = $_POST['id'];
        $id = 19;
        // $type = $_POST['actype'];        
        $sel = Db::name('datainfo')->where('id',$id)->find();
        // $selinfo = Db::name('datainfo')->where('phonesn',$sel['phonesn'])->where('dyaccount',$sel['dyaccount'])->select();
        $subQuery = Db::table('media-datainfo')
        ->where('phonesn',$sel['phonesn'])
        ->where('dyaccount',$sel['dyaccount'])
        ->buildSql();
        $selinfo = Db::table($subQuery.' a')
                ->group('a.time')
                ->select();


                
                // echo date('Y-m-d', time());
                // echo time();  //1539935604
                // 1539935617   1539935640
        // $this->assign('selinfo',$selinfo);
        return json_encode($selinfo);
        // return $this->fetch();
    }
}
