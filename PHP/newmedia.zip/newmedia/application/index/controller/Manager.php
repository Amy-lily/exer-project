<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Session;
header('Content-Type:text/html; charset=utf-8');
class Manager extends Controller
{
    // 管理员页面 首页
    public function index()
    {
        $subQuery = Db::table('media-datainfo')
        ->order('id desc')
        ->buildSql();
        $sel = Db::table($subQuery.' a')
                ->group('a.phonesn')
                ->select();
        $this->assign('empty','<p>暂时没有数据</p>');
        $this->assign('sel',$sel);
       return $this->fetch();        
    }
//    ---------------------------------------------------------手机信息管理
    public function phonelist(){
        $subQuery = Db::table('media-datainfo')
        ->order('id desc')
        ->where('phonesn','<>','')
        ->buildSql();
        $sel = Db::table($subQuery.' a')
                ->group('a.phonesn')
                ->select();
        $this->assign('empty','<p>暂无数据</p>');
        $this->assign('sel',$sel);
        return $this->fetch();
    }
    //添加 手机信息
    public function addphone(){
        if(request()->isPost()){
            $data = [
                'phonesn'       => $_POST['phonesn'],
                'phonebrand'    => $_POST['phonebrand'],
                'phonesim1'     => $_POST['phonesim1'],
                'phonesim2'     => $_POST['phonesim2'],
                'phonecreate1'  => $_POST['phonecreate1'],
                'phonecreate2'  => $_POST['phonecreate2'],
                'phonecharge'   => $_POST['phonecharge'],
                'time'          => time()
            ];
            $sel = Db::name('datainfo')->where('phonesn',$data['phonesn'])->find();
            if(!$sel){ 
                $inser = Db::name('datainfo')->insert($data);
                if($inser){
                    return $this->success('添加手机信息成功','Manager/phonelist');
                }else{
                    return $this->error('添加手机信息失败,请稍后再试');
                }
            }else{
                return $this->error('已经存在当前的手机编号，请重新添加');
            }
          
        }else{
            return $this->fetch();
        }
    }

    //编辑手机信息
    public function editphone(){
        if(request()->isPost()){
            $id = $_POST['id'];
            $data = [
                'phonesn'       => $_POST['phonesn'],
                'phonebrand'    => $_POST['phonebrand'],
                'phonesim1'     => $_POST['phonesim1'],
                'phonesim2'     => $_POST['phonesim2'],
                'phonecreate1'  => $_POST['phonecreate1'],
                'phonecreate2'  => $_POST['phonecreate2'],
                'phonecharge'   => $_POST['phonecharge']
            ];
            $upda = Db::name('datainfo')->where('id',$id)->update($data);
            if($upda){
                return $this->success('修改手机信息成功','Manager/phonelist');
            }else{
                return $this->error('修改手机信息失败');
            }
        }else{
            $id = $_GET['id'];
            $sel = Db::name('datainfo')->where('id',$id)->find();
            if($sel){
                $this->assign('sel',$sel);
                return $this->fetch();
            }else{
                return $this->error('无数据');
            }
        }
    }
    //删除手机信息
    public function delphone(){
        $id = $_GET['id'];
        $del = Db::name('datainfo')->where('id',$id)->delete();
        if($del){
            return $this->success('删除手机信息成功','Manager/phonelist');
        }else{
            return $this->error('删除手机信息失败');
        }
    }


    // -------------------------------------------------------------------- 抖音账号管理 
    public function dylist(){
        $subQuery = Db::name('datainfo')
                    ->field('id,phonesn,dyaccount,dypass,dyname,dyfans,time')
                    ->where('dyaccount','<>','')
                    ->order('id desc')
                    ->buildSql();
        $dylist = Db::table($subQuery.' a')
                    ->group('a.dyaccount')
                    ->select();                
        $this->assign('sel',$dylist);
        $this->assign('empty','<p>暂时没有数据</p>');
        return $this->fetch();
    }

    //添加抖音数据 
    public function adddy(){
        if(request()->isPost()){
            $id = $_POST['pid'];
            $selsn = Db::name('datainfo')->where('id',$id)->find();
            $unit = $_POST['unit'];
            $data = [
                'phonesn'      => $selsn['phonesn'],
                'phonebrand'   => $selsn['phonebrand'],
                'phonesim1'    => $selsn['phonesim1'],
                'phonesim2'    => $selsn['phonesim2'],
                'phonecreate1' => $selsn['phonecreate1'],
                'phonecreate2' => $selsn['phonecreate2'],
                'phonecharge'  => $selsn['phonecharge'],
                'dyaccount'    => $_POST['dyaccount'],
                'dypass'       => $_POST['dypass'],
                'dyname'       => $_POST['dyname'],
                'dyfans'       => $_POST['dyfans'],
                'ksaccount'    => $selsn['ksaccount'],
                'kspass'       => $selsn['kspass'],
                'ksname'       => $selsn['ksname'],
                'ksfans'       => $selsn['ksfans'],
                'wxaccount'    => $selsn['wxaccount'],
                'wxpass'       => $selsn['wxpass'],
                'wxname'       => $selsn['wxname'],
                'wxfans'       => $selsn['wxfans'],
                'time'         => time()
            ];         
            
            $selresu = Db::name('datainfo')->where('dyaccount',$data['dyaccount'])->select();
            if($selsn['dyaccount']<>''){
                if($selsn['dyaccount']<>$data['dyaccount']){
                    return $this->error($selsn['phonesn'].' 已经存在抖音账号，不能重复添加');
                }else{
                    return $this->error($selsn['dyaccount'].' 抖音账号已经存在');
                }
            }else{
                if($selresu){
                    return $this->error($data['dyaccount'].' 抖音账号已经存在');
                }
                if($unit =='ge'){
                    $sing = number_format($data['dyfans']/10000,4,'.','');
                    $data['dyfans'] = $sing;
                }    
                $inser = Db::name('datainfo')->where('phonesn',$data['phonesn'])->update($data);
                if($inser){
                    return $this->success('添加抖音账号信息成功','Manager/dylist');
                }else{
                    return $this->error('添加抖音账号信息失败');
                }  
            }
        }else{
            $subQuery = Db::name('datainfo')
            ->field('id,phonesn,dyaccount,dypass,dyname,dyfans,time')
            ->where('dyaccount','=','')
            ->order('id desc')
            ->buildSql();
            $sel = Db::table($subQuery.' a')
                        ->group('a.phonesn')
                        ->select();  
            if($sel){
                $this->assign('sel',$sel);
                return $this->fetch();
            }else{
                return $this->error('目前所有的手机编号都存在对应的抖音账号，需要添加手机编号再进行抖音账号的添加','Manager/dylist','5');
            }     
        }
    }
    //编辑抖音信息
    public function editdy(){
        if(request()->isPost()){
            $id = $_POST['id'];//原抖音id
            $newid = $_POST['pid'];//修改后抖音id
            $data = [
                'dyaccount' => $_POST['dyaccount'],
                'dypass'    => $_POST['dypass'],
                'dyname'    => $_POST['dyname'],
                'dyfans'    => $_POST['dyfans']
            ];
            $selold = Db::name('datainfo')->where('id',$id)->find();//原抖音数据信息
            $selnew = Db::name('datainfo')->where('id',$newid)->find();//修改后抖音数据信息

            //修改了手机编号 
            if($selold['phonesn']<>$selnew['phonesn']){             
                // 判断新的手机编号 是否存在 抖音账号  
                if($selnew['dyaccount']<>'' && $selnew['dyaccount']<>$selold['dyaccount']){
                    return $this->error($selnew['phonesn'].' 已经存在抖音账号,不可重复添加抖音号');
                }
            }
            if($data['dyaccount']<>$selold['dyaccount']){
                $seldy = Db::name('datainfo')->where('dyaccount',$data['dyaccount'])->select();
                if($seldy){
                    return $this->error($data['dyaccount'].' 抖音账号已经存在，不能重复添加');
                }
            }     
            $unit = $_POST['unit'];            
            if($unit =='ge'){
                $sing = number_format($data['dyfans']/10000,4,'.','');
                $data['dyfans'] = $sing;
            }  
           
            // 将表中所有相关信息都进行修改 
            $upda = Db::name('datainfo')->where('phonesn',$selnew['phonesn'])->where('dyaccount',$selold['dyaccount'])->update($data);
            if($upda){
                return $this->success('修改抖音账号信息成功','Manager/dylist');
            }else{
                return $this->error('修改抖音账号信息失败');
            }  
        }else{
            $id = $_GET['id'];            
            $sel = Db::name('datainfo')->where('id',$id)->find();
            $pid = Db::name('datainfo')->group('phonesn')->select();//按手机编号分组
            $this->assign('pid',$pid);
            $this->assign('sel',$sel);
            return $this->fetch();
        }
}

    //修改抖音粉丝量
    public function editdyfans(){
        if(request()->isPost()){
            $id = $_POST['id'];
            $sel = Db::name('datainfo')->where('id',$id)->find();
            $data = [
                'phonesn'      => $sel['phonesn'],
                'phonebrand'   => $sel['phonebrand'],
                'phonesim1'    => $sel['phonesim1'],
                'phonesim2'    => $sel['phonesim2'],
                'phonecreate1' => $sel['phonecreate1'],
                'phonecreate2' => $sel['phonecreate2'],
                'phonecharge'  => $sel['phonecharge'],
                'dyaccount'    => $sel['dyaccount'],
                'dyaccount'    => $sel['dyaccount'],
                'dypass'       => $sel['dypass'],
                'dyname'       => $sel['dyname'],
                'dyfans'       => $_POST['dyfans'],
                'ksaccount'    =>$sel['ksaccount'],
                'kspass'       => $sel['kspass'],
                'ksname'       => $sel['ksname'],
                'ksfans'       => $sel['ksfans'],
                'wxaccount'    => $sel['wxaccount'],
                'wxpass'       => $sel['wxpass'],
                'wxname'       => $sel['wxname'],
                'wxfans'       => $sel['wxfans'],
                'time'         => time()
            ];   
            // 判断粉丝单位     
            $unit = $_POST['unit'];            
            if($unit =='ge'){
                $sing = number_format($data['dyfans']/10000,4,'.','');
                $data['dyfans'] = $sing;
            }     
            
            $upda = Db::name('datainfo')->insert($data);
            if($upda){
                return $this->success('修改粉丝数量成功','Manager/dylist');
            }else{
                return $this->error('修改粉丝数据失败');
            }
        }else{
            $id=$_GET['id'];
            $oldinfo = DB::name('datainfo')->where('id',$id)->find();
            $this->assign('info',$oldinfo);
            return $this->fetch();
        }
        
    }

    //删除抖音数据 
    public function deldy(){
        $id = $_GET['id'];
        $sel = Db::name('datainfo')->where('id',$id)->find();
        $data = [
            'dyaccount' => '',
            'dypass'    => '',
            'dyfans'    => '',
            'dyname'    => ''
        ];
        $upda = Db::name('datainfo')->where('phonesn',$sel['phonesn'])->where('dyaccount',$sel['dyaccount'])->update($data);
        if($upda){
            return $this->success('删除抖音账号信息成功','Manager/dylist');
        }else{
            return $this->error('删除抖音账号信息失败，请稍后再试');
        }
    }

    // ----------------------------------------------------- 快手 
    public function kslist(){
        $subQuery = Db::name('datainfo')
            ->field('id,phonesn,ksaccount,kspass,ksname,ksfans,time')
            ->where('phonesn','<>','')
            ->where('ksaccount','<>','')
            ->order('id desc')
            ->buildSql();
        $kslist = Db::table($subQuery.' a')
            ->group('a.ksaccount')
            ->select();     

        $this->assign('sel',$kslist);
        $this->assign('empty','<p>暂时没有数据</p>');
        return $this->fetch();
    }

    //添加快手数据
    public function addks(){
        if(request()->isPost()){
            $id = $_POST['pid'];
            $sel = Db::name('datainfo')->where('id',$id)->find();             
            $data = [
                'phonesn'      => $sel['phonesn'],
                'phonebrand'   => $sel['phonebrand'],
                'phonesim1'    => $sel['phonesim1'],
                'phonesim2'    => $sel['phonesim2'],
                'phonecreate1' => $sel['phonecreate1'],
                'phonecreate2' => $sel['phonecreate2'],
                'phonecharge'  => $sel['phonecharge'],
                'dyaccount'    => $sel['dyaccount'],
                'dypass'       => $sel['dypass'],
                'dyname'       => $sel['dyname'],
                'dyfans'       => $sel['dyfans'],
                'ksaccount'    => $_POST['ksaccount'],
                'kspass'       => $_POST['kspass'],
                'ksname'       => $_POST['ksname'],
                'ksfans'       => $_POST['ksfans'],
                'wxaccount'    => $sel['wxaccount'],
                'wxpass'       => $sel['wxpass'],
                'wxname'       => $sel['wxname'],
                'wxfans'       => $sel['wxfans'],
                'time'         => time()
            ];         
            $selresu = Db::name('datainfo')->where('ksaccount',$data['ksaccount'])->select();
            if($sel['ksaccount']<>''){
                if($sel['ksaccount']<>$data['ksaccount']){
                    return $this->error($sel['phonesn'].' 已经存在快手账号，不能重复添加');
                }else{
                    return $this->error($sel['ksaccount'].' 快手账号已经存在');
                }
            }else{
                if($selresu){
                    return $this->error($data['ksaccount'].' 快手账号已经存在');
                }
                $unit = $_POST['unit'];//获取粉丝量单位 
                if($unit =='ge'){
                    $sing = number_format($data['dyfans']/10000,4,'.','');
                    $data['dyfans'] = $sing;
                }   
                $inser = Db::name('datainfo')->where('phonesn',$data['phonesn'])->update($data);
                if($inser){
                    return $this->success('添加快手账号信息成功','Manager/kslist');
                }else{
                    return $this->error('添加快手账号信息失败');
                }  
            }
        }else{
            $subQuery = Db::name('datainfo')
            ->field('id,phonesn,ksaccount,kspass,ksname,ksfans,time')
            ->where('ksaccount','=','')
            ->order('id desc')
            ->buildSql();
            $selinfo = Db::table($subQuery.' a')
                        ->group('a.phonesn')
                        ->select();  
            if($selinfo){
                $this->assign('sel',$selinfo);
                return $this->fetch();
            }else{
                return $this->error('目前所有的手机编号都存在对应的快手账号，需要添加手机编号再进行快手账号的添加','Manager/kslist','5');
            }     
        }
    }

    //编辑快手信息
    public function editks(){
        if(request()->isPost()){
            $id = $_POST['id'];//原快手id
            $newid = $_POST['pid'];//修改后快手id
            $data = [
                'ksaccount' => $_POST['ksaccount'],
                'kspass'    => $_POST['kspass'],
                'ksname'    => $_POST['ksname'],
                'ksfans'    => $_POST['ksfans']
            ];
            $selold = Db::name('datainfo')->where('id',$id)->find();//原快手数据信息
            $selnew = Db::name('datainfo')->where('id',$newid)->find();//修改后快手数据信息
            $unit = $_POST['unit'];//获取粉丝量单位 ，如果为  个，需要将个转换为万
            if($unit =='ge'){
                $sing = number_format($data['ksfans']/10000,4,'.','');
                $data['ksfans'] = $sing;
            }
            //修改了手机编号 
            if($selold['phonesn']<>$selnew['phonesn']){             
                // 判断新的手机编号 是否存在 快手账号  
                if($selnew['ksaccount']<>'' && $selnew['ksaccount']<>$selold['ksaccount']){
                    return $this->error($selnew['phonesn'].' 已经存在快手账号,不可重复添加快手号');
                }
            }
            // 修改了快手账号，判断新添加的账号是否存在  
            if($data['ksaccount']<>$selold['ksaccount']){
                $selks = Db::name('datainfo')->where('ksaccount',$data['ksaccount'])->select();
                if($selks){
                    return $this->error($data['ksaccount'].' 快手账号已经存在，不能重复添加');
                }
            }     
            // 将表中所有 手机编号、快手账号 相同的记录都 需要进行修改
            $upda = Db::name('datainfo')->where('phonesn',$selnew['phonesn'])->where('ksaccount',$selold['ksaccount'])->update($data);
            if($upda){
                return $this->success('修改快手账号信息成功','Manager/kslist');
            }else{
                return $this->error('修改快手账号信息失败');
            }  
        }else{
            $id = $_GET['id'];            
            $sel = Db::name('datainfo')->where('id',$id)->find();
            $pid = Db::name('datainfo')->group('phonesn')->select();//按手机编号分组
            $this->assign('pid',$pid);
            $this->assign('sel',$sel);
            return $this->fetch();
        }
    }

    //修改快手粉丝量
    public function editksfans(){
        if(request()->isPost()){
            $id = $_POST['id'];
            $sel = Db::name('datainfo')->where('id',$id)->find();
            $data = [
                'phonesn'      => $sel['phonesn'],
                'phonebrand'   => $sel['phonebrand'],
                'phonesim1'    => $sel['phonesim1'],
                'phonesim2'    => $sel['phonesim2'],
                'phonecreate1' => $sel['phonecreate1'],
                'phonecreate2' => $sel['phonecreate2'],
                'phonecharge'  => $sel['phonecharge'],
                'dyaccount'    => $sel['dyaccount'],
                'dyaccount'    => $sel['dyaccount'],
                'dypass'       => $sel['dypass'],
                'dyname'       => $sel['dyname'],
                'dyfans'       => $sel['dyfans'],
                'ksaccount'    =>$sel['ksaccount'],
                'kspass'       => $sel['kspass'],
                'ksname'       => $sel['ksname'],
                'ksfans'       => $_POST['ksfans'],
                'wxaccount'    => $sel['wxaccount'],
                'wxpass'       => $sel['wxpass'],
                'wxname'       => $sel['wxname'],
                'wxfans'       => $sel['wxfans'],
                'time'         => time()
            ];            
            $unit = $_POST['unit'];//获取粉丝量单位 
            if($unit =='ge'){
                $sing = number_format($data['ksfans']/10000,4,'.','');
                $data['ksfans'] = $sing;
            }
            
            $upda = Db::name('datainfo')->insert($data);
            if($upda){
                return $this->success('修改粉丝数量成功','Manager/kslist');
            }else{
                return $this->error('修改粉丝数据失败');
            }
        }else{
            $id=$_GET['id'];
            $oldinfo = DB::name('datainfo')->where('id',$id)->find();
            $this->assign('info',$oldinfo);
            return $this->fetch();
        }
    }

    //删除快手信息
    public function delks(){
        $id = $_GET['id'];
        $sel = Db::name('datainfo')->where('id',$id)->find();
        $data = [
            'ksaccount' => '',
            'kspass'    => '',
            'ksfans'    => '',
            'ksname'    => ''
        ];
        $upda = Db::name('datainfo')->where('phonesn',$sel['phonesn'])->where('ksaccount',$sel['ksaccount'])->update($data);
        if($upda){
            return $this->success('删除快手账号信息成功','Manager/kslist');
        }else{
            return $this->error('删除快手账号信息失败，请稍后再试');
        }
    }

    // ----------------------------------------------------------- 微信
    public function wxlist(){
        $subQuery = Db::name('datainfo')
        ->field('id,phonesn,wxaccount,wxpass,wxname,wxfans,time')
        ->where('wxaccount','<>','')
        ->order('id desc')
        ->buildSql();
        $wxlist = Db::table($subQuery.' a')
                ->group('a.wxaccount')
                ->select();                
        $this->assign('sel',$wxlist);
        $this->assign('empty','<p>暂时没有数据</p>');
        return $this->fetch();
    }

    //添加微信账号信息
    public function addwx(){
        if(request()->isPost()){
            $id = $_POST['pid'];
            $selsn = Db::name('datainfo')->where('id',$id)->find();
            $unit = $_POST['unit'];
            $data = [
                'phonesn'      => $selsn['phonesn'],
                'phonebrand'   => $selsn['phonebrand'],
                'phonesim1'    => $selsn['phonesim1'],
                'phonesim2'    => $selsn['phonesim2'],
                'phonecreate1' => $selsn['phonecreate1'],
                'phonecreate2' => $selsn['phonecreate2'],
                'phonecharge'  => $selsn['phonecharge'],
                'dyaccount'    => $selsn['dyaccount'],
                'dypass'       => $selsn['dypass'],
                'dyname'       => $selsn['dyname'],
                'dyfans'       => $selsn['dyfans'],
                'ksaccount'    => $selsn['ksaccount'],
                'kspass'       => $selsn['kspass'],
                'ksname'       => $selsn['ksname'],
                'ksfans'       => $selsn['ksfans'],
                'wxaccount'    => $_POST['wxaccount'],
                'wxpass'       => $_POST['wxpass'],
                'wxname'       => $_POST['wxname'],
                'wxfans'       => $_POST['wxfans'],
                'time'         => time()
            ];         
            
            $selresu = Db::name('datainfo')->where('wxaccount',$data['wxaccount'])->select();
            if($selsn['wxaccount']<>''){
                if($selsn['wxaccount']<>$data['wxaccount']){
                    return $this->error($selsn['phonesn'].' 已经存在微信账号，不能重复添加');
                }else{
                    return $this->error($selsn['wxaccount'].' 微信账号已经存在');
                }
            }else{
                if($selresu){
                    return $this->error($data['wxaccount'].' 微信账号已经存在');
                }
                if($unit =='ge'){
                    $sing = number_format($data['wxfans']/10000,4,'.','');
                    $data['wxfans'] = $sing;
                }    
                $inser = Db::name('datainfo')->where('phonesn',$data['phonesn'])->update($data);
                if($inser){
                    return $this->success('添加微信账号信息成功','Manager/wxlist');
                }else{
                    return $this->error('添加微信账号信息失败');
                }  
            }
        }else{
            $subQuery = Db::name('datainfo')
            ->field('id,phonesn,wxaccount,wxpass,wxname,wxfans,time')
            ->where('wxaccount','=','')
            ->order('id desc')
            ->buildSql();
            $sel = Db::table($subQuery.' a')
                        ->group('a.phonesn')
                        ->select();  
            if($sel){
                $this->assign('sel',$sel);
                return $this->fetch();
            }else{
                return $this->error('目前所有的手机编号都存在对应的微信账号，需要添加手机编号再进行微信账号的添加','Manager/dylist','5');
            }     
        }
    }

    //编辑微信账号信息
    public function editwx(){
        if(request()->isPost()){
            $id = $_POST['id'];//原微信id
            $newid = $_POST['pid'];//修改后微信id
            $data = [
                'wxaccount' => $_POST['wxaccount'],
                'wxpass'    => $_POST['wxpass'],
                'wxname'    => $_POST['wxname'],
                'wxfans'    => $_POST['wxfans']
            ];
            $unit = $_POST['unit'];//获取微信好友量 单位 
            if($unit == 'ge'){
                $sing = number_format($data['wxfans']/10000,4,'.','');
                $data['wxfans'] = $sing;
            }
            $selold = Db::name('datainfo')->where('id',$id)->find();//原微信数据信息
            $selnew = Db::name('datainfo')->where('id',$newid)->find();//修改后微信数据信息

            //修改了手机编号 
            if($selold['phonesn']<>$selnew['phonesn']){             
                // 判断新的手机编号 是否存在 微信账号  
                if($selnew['wxaccount']<>'' && $selnew['wxaccount']<>$selold['wxaccount']){
                    return $this->error($selnew['phonesn'].' 已经存在微信账号,不可重复添加微信号');
                }
            }
            if($data['wxaccount']<>$selold['wxaccount']){
                $selwx = Db::name('datainfo')->where('wxaccount',$data['wxaccount'])->select();
                if($selwx){
                    return $this->error($data['wxaccount'].' 微信账号已经存在，不能重复添加');
                }
            }     
            // 将表中所有相关信息都进行修改 
            $upda = Db::name('datainfo')->where('phonesn',$selnew['phonesn'])->where('wxaccount',$selold['wxaccount'])->update($data);
            if($upda){
                return $this->success('修改微信账号信息成功','Manager/wxlist');
            }else{
                return $this->error('修改微信账号信息失败');
            }  
        }else{
            $id = $_GET['id'];            
            $sel = Db::name('datainfo')->where('id',$id)->find();
            $pid = Db::name('datainfo')->group('phonesn')->select();//按手机编号分组
            $this->assign('pid',$pid);
            $this->assign('sel',$sel);
            return $this->fetch();
        }
    }
    //修改微信粉丝
    public function editwxfans(){
        if(request()->isPost()){
            $id = $_POST['id'];
            $sel = Db::name('datainfo')->where('id',$id)->find();
            $data = [
                'phonesn'      => $sel['phonesn'],
                'phonebrand'   => $sel['phonebrand'],
                'phonesim1'    => $sel['phonesim1'],
                'phonesim2'    => $sel['phonesim2'],
                'phonecreate1' => $sel['phonecreate1'],
                'phonecreate2' => $sel['phonecreate2'],
                'phonecharge'  => $sel['phonecharge'],
                'dyaccount'    => $sel['dyaccount'],
                'dyaccount'    => $sel['dyaccount'],
                'dypass'       => $sel['dypass'],
                'dyname'       => $sel['dyname'],
                'dyfans'       => $sel['dyfans'],
                'ksaccount'    =>$sel['ksaccount'],
                'kspass'       => $sel['kspass'],
                'ksname'       => $sel['ksname'],
                'ksfans'       => $sel['ksfans'],
                'wxaccount'    => $sel['wxaccount'],
                'wxpass'       => $sel['wxpass'],
                'wxname'       => $sel['wxname'],
                'wxfans'       => $_POST['wxfans'],
                'time'         => time()
            ];       
            $unit = $_POST['unit'];//获取微信好友量 单位 
            if($unit == 'ge'){
                $sing = number_format($data['wxfans']/10000,4,'.','');
                $data['wxfans'] = $sing;
            }     
            $upda = Db::name('datainfo')->insert($data);
            if($upda){
                return $this->success('修改粉丝数量成功','Manager/wxlist');
            }else{
                return $this->error('修改粉丝数据失败');
            }
        }else{
            $id=$_GET['id'];
            $oldinfo = DB::name('datainfo')->where('id',$id)->find();
            $this->assign('info',$oldinfo);
            return $this->fetch();
        }
    }

    //删除微信账号
    public function delwx(){
        $id = $_GET['id'];
        $sel = Db::name('datainfo')->where('id',$id)->find();
        $data = [
            'wxaccount' => '',
            'wxpass'    => '',
            'wxfans'    => '',
            'wxname'    => ''
        ];
        $upda = Db::name('datainfo')->where('phonesn',$sel['phonesn'])->where('wxaccount',$sel['wxaccount'])->update($data);
        if($upda){
            return $this->success('删除微信账号信息成功','Manager/wxlist');
        }else{
            return $this->error('删除微信账号信息失败，请稍后再试');
        }
    }
}
